## Description

clothing ecommerce mobile app client with React native.
[Try with expo](https://expo.io/@b-haytham/clothes-ecommerce-mobile)


## Installation

```bash
$ npm install
```

## Running the app

```bash

# development
$ npm start

```

